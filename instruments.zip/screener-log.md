# Participant log

Recruitment target: 3–5 people, each doing ONE combined session (mini-interview + wireframe check + usability test, see `session-runsheet.md`), one recording per person. 1–2 who talk freely get the extended interview and count as the deep interviews. The 431-comment corpus is the primary needfinding source; sessions triangulate it.

| ID  | Date | Stage / field | Abroad status | Session | Consent signed | Recording file |
| --- | ---- | ------------- | ------------- | ------- | -------------- | -------------- |
| P01 |      |               |               |         |                |                |
| P02 |      |               |               |         |                |                |
| P03 |      |               |               |         |                |                |
| P04 |      |               |               |         |                |                |
| P05 |      |               |               |         |                |                |
| P06 |      |               |               |         |                |                |
| P07 |      |               |               |         |                |                |
| P08 |      |               |               |         |                |                |

Session codes: INT = interview, E1 = low-fi walkthrough, E2 = medium-fi usability test.
